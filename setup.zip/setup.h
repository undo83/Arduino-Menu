#ifndef SETUP_H_INCLUDED
#define SETUP_H_INCLUDED

char json[] ="{\"setup\":{\"refresh\":{\"on_time\":0,\"on_value_change\":true,\"on_input_trigger\":[0,1]},\"buttons\":{\"click\":300,\"confirmation\":1,\"homing\":60}},\"buttons\":[{\"pin\":10,\"numbers\":[0],\"letters\":[\"a\",\"b\",\"c\"],\"special\":[],\"fn\":[]},{\"pin\":11,\"numbers\":[1],\"letters\":[\"d\",\"e\",\"f\"],\"special\":[],\"fn\":[]},{\"pin\":12,\"numbers\":[],\"letters\":[],\"special\":[\"up\"],\"fn\":[]},{\"pin\":13,\"numbers\":[],\"letters\":[],\"special\":[\"down\"],\"fn\":[]},{\"pin\":14,\"numbers\":[],\"letters\":[],\"special\":[\"enter\"],\"fn\":[]},{\"pin\":15,\"numbers\":[],\"letters\":[],\"special\":[\"fn\"],\"fn\":[]}],\"menus\":[{\"id\":\"home\",\"lines\":[{\"style\":\"flat\",\"height\":4,\"tags\":[{\"length\":7,\"from_var\":\"temperature\",\"type\":\"writable\",\"normal\":{\"font\":\"Arial\",\"size\":10,\"color\":0,\"background\":65535,\"style\":\"flat\",\"align\":\"right\"},\"selected\":{\"font\":\"Arial\",\"size\":10,\"color\":65535,\"background\":0,\"style\":\"flat\",\"align\":\"right\"}}]}]},{\"id\":\"temperature\",\"lines\":[]}]}";

#endif // SETUP_H_INCLUDED
